# 2123-ia-aplicada-a-data-science-construccion-de-visualizaciones
Este repositorio corresponde al entrenamiento de Python: IA aplicada a Data Science: Uso de IA en la construcción de visualizaciones de Datos de Alura Latam.

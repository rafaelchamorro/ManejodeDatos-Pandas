# 2145-data-science-probando-relaciones-con-regresion-lineal
Este repositorio corresponde al entrenamiento de Data Science: Probando relaciones con regresión lineal de Alura Latam.
